package com.cleanpvp;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.StatCollector;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import org.lwjgl.input.Keyboard;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public final class HudManager {
    private static HudConfig config;
    private static KeyBinding openEditorKey;
    private static final ClickTracker clickTracker = new ClickTracker();

    private HudManager() {
    }

    public static void initialize() {
        config = HudConfigManager.load();
        openEditorKey = new KeyBinding("key.cleanpvp.open_editor", Keyboard.KEY_RSHIFT, "CleanPVP");
        ClientRegistry.registerKeyBinding(openEditorKey);
        MinecraftForge.EVENT_BUS.register(new HudManager());
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            Minecraft client = Minecraft.func_71410_x();
            clickTracker.tick(client);
            if (openEditorKey.func_151468_f()) {
                client.func_147108_a(new HudEditorScreen());
            }
        }
    }

    @SubscribeEvent
    public void onRenderHud(RenderGameOverlayEvent.Text event) {
        Minecraft client = Minecraft.func_71410_x();
        if (client.field_71439_g == null || client.field_71474_y.field_74319_N || client.field_71462_r instanceof HudEditorScreen) {
            return;
        }

        for (HudWidget widget : HudWidget.values()) {
            HudConfig.WidgetSettings settings = config.getWidgetSettings(widget);
            if (settings != null && settings.enabled) {
                WidgetBounds bounds = getWidgetBounds(client, widget);
                renderWidget(client, widget, bounds.x, bounds.y, false);
            }
        }
    }

    public static HudConfig getConfig() {
        return config;
    }

    public static void persist() {
        HudConfigManager.save(config);
    }

    public static int getLeftCps() {
        return clickTracker.getLeftCps();
    }

    public static int getRightCps() {
        return clickTracker.getRightCps();
    }

    public static WidgetBounds getWidgetBounds(Minecraft client, HudWidget widget) {
        ScaledResolution sr = new ScaledResolution(client);
        HudConfig.WidgetSettings settings = config.getWidgetSettings(widget);
        int x = (int) (settings.xNorm * sr.func_78326_a());
        int y = (int) (settings.yNorm * sr.func_78328_b());
        return new WidgetBounds(x, y, getWidgetWidth(widget, client), getWidgetHeight(widget, client));
    }

    public static void setWidgetPosition(HudWidget widget, int x, int y, int screenWidth, int screenHeight) {
        HudConfig.WidgetSettings settings = config.getWidgetSettings(widget);
        settings.xNorm = (double) x / Math.max(1, screenWidth);
        settings.yNorm = (double) y / Math.max(1, screenHeight);
    }

    public static void renderWidget(Minecraft client, HudWidget widget, int x, int y, boolean inEditor) {
        int width = getWidgetWidth(widget, client);
        int height = getWidgetHeight(widget, client);
        int color = currentOutlineColor();
        
        // SIMPLE BACKGROUND
        if (config.fillMode == HudConfig.FillMode.SOLID_BOX) {
            Gui.func_73734_a(x, y, x + width, y + height, (color & 0x00FFFFFF) | 0x44000000);
        }
        
        // SIMPLE OUTLINE
        Gui.func_73734_a(x, y, x + width, y + 1, color);
        Gui.func_73734_a(x, y + height - 1, x + width, y + height, color);
        Gui.func_73734_a(x, y, x + 1, y + height, color);
        Gui.func_73734_a(x + width - 1, y, x + width, y + height, color);

        if (inEditor) {
            // Extra white outline in editor
            drawOutline(x - 1, y - 1, width + 2, height + 2, 0x88FFFFFF);
        }

        FontRenderer fr = client.field_71466_p;
        switch (widget) {
            case KEYSTROKES:
                renderKeystrokes(client, x, y);
                break;
            case FPS:
                fr.func_175063_a("FPS: " + Minecraft.func_175610_ah(), x + 4, y + 5, 0xFFFFFFFF);
                break;
            case CPS:
                fr.func_175063_a("CPS: " + getLeftCps() + " | " + getRightCps(), x + 4, y + 5, 0xFFFFFFFF);
                break;
            case ARMOR:
                renderArmor(client, x, y);
                break;
            case POTIONS:
                renderPotions(client, x, y);
                break;
        }
    }

    private static void renderKeystrokes(Minecraft client, int x, int y) {
        float scale = config.keystrokesScale.factor();
        int kw = (int)(16 * scale);
        int kh = (int)(14 * scale);
        int gap = (int)(2 * scale);

        drawSimpleKey(client, "W", x + kw + gap + 3, y + 4, kw, kh, client.field_71474_y.field_74351_w.func_151470_d());
        drawSimpleKey(client, "A", x + 3, y + kh + gap + 4, kw, kh, client.field_71474_y.field_74370_x.func_151470_d());
        drawSimpleKey(client, "S", x + kw + gap + 3, y + kh + gap + 4, kw, kh, client.field_71474_y.field_74368_y.func_151470_d());
        drawSimpleKey(client, "D", x + (kw + gap) * 2 + 3, y + kh + gap + 4, kw, kh, client.field_71474_y.field_74366_z.func_151470_d());
    }

    private static void drawSimpleKey(Minecraft client, String text, int x, int y, int w, int h, boolean down) {
        int color = currentOutlineColor();
        Gui.func_73734_a(x, y, x + w, y + h, down ? (color & 0x00FFFFFF) | 0x77000000 : 0x44000000);
        drawOutline(x, y, w, h, color);
        client.field_71466_p.func_175063_a(text, x + w/2 - client.field_71466_p.func_78256_a(text)/2, y + h/2 - 4, 0xFFFFFFFF);
    }

    private static void renderArmor(Minecraft client, int x, int y) {
        int ly = y + 4;
        for (int i = 3; i >= 0; i--) {
            ItemStack s = client.field_71439_g.field_71071_by.field_70460_b[i];
            if (s != null) {
                RenderHelper.func_74520_c();
                client.func_175599_af().func_180450_b(s, x + 4, ly - 2);
                RenderHelper.func_74518_a();
                client.field_71466_p.func_175063_a(durabilityText(s), x + 24, ly + 4, 0xFFFFFFFF);
            } else {
                client.field_71466_p.func_175063_a("None", x + 24, ly + 4, 0xFFFFFFFF);
            }
            ly += 18;
        }
    }

    private static void renderPotions(Minecraft client, int x, int y) {
        int ly = y + 4;
        Collection<PotionEffect> effects = client.field_71439_g.func_70651_bq();
        if (effects.isEmpty()) {
            client.field_71466_p.func_175063_a("No Effects", x + 4, ly, 0xFFFFFFFF);
            return;
        }
        for (PotionEffect e : effects) {
            String s = StatCollector.func_74838_a(e.func_76453_d()) + " " + Potion.func_76389_a(e);
            client.field_71466_p.func_175063_a(s, x + 4, ly, 0xFFFFFFFF);
            ly += 10;
        }
    }

    public static int getWidgetWidth(HudWidget widget, Minecraft client) {
        switch (widget) {
            case KEYSTROKES: return (int)(66 * config.keystrokesScale.factor());
            case FPS: return 70;
            case CPS: return 90;
            case ARMOR: return 92;
            case POTIONS: return 150;
            default: return 0;
        }
    }

    public static int getWidgetHeight(HudWidget widget, Minecraft client) {
        switch (widget) {
            case KEYSTROKES: return (int)(52 * config.keystrokesScale.factor());
            case FPS: return 18;
            case CPS: return 18;
            case ARMOR: return 76;
            case POTIONS: return 70;
            default: return 0;
        }
    }

    private static int currentOutlineColor() {
        if (config.colorMode == HudConfig.ColorMode.RAINBOW) {
            return Color.HSBtoRGB((System.currentTimeMillis() % 5000L) / 5000f, 0.8f, 1f);
        }
        return config.solidColor;
    }

    private static String durabilityText(ItemStack stack) {
        if (!stack.func_77984_f()) return stack.func_82833_r();
        return (stack.func_77958_k() - stack.func_77952_i()) + "/" + stack.func_77958_k();
    }

    public static void drawOutline(int x, int y, int w, int h, int color) {
        Gui.func_73734_a(x, y, x + w, y + 1, color);
        Gui.func_73734_a(x, y + h - 1, x + w, y + h, color);
        Gui.func_73734_a(x, y, x + 1, y + h, color);
        Gui.func_73734_a(x + w - 1, y, x + w, y + h, color);
    }

    public static void cycleColorMode() { config.colorMode = config.colorMode == HudConfig.ColorMode.SOLID ? HudConfig.ColorMode.RAINBOW : HudConfig.ColorMode.SOLID; }
    public static void cycleFillMode() { config.fillMode = config.fillMode == HudConfig.FillMode.OUTLINE_ONLY ? HudConfig.FillMode.SOLID_BOX : HudConfig.FillMode.OUTLINE_ONLY; }
    public static void cycleSolidColor() {
        int[] p = {0xFF00B7FF, 0xFFFF4D4D, 0xFF7BFF6A, 0xFFFFD95E, 0xFFC48BFF, 0xFFFFFFFF};
        int idx = 0;
        for (int i=0; i<p.length; i++) if (p[i] == config.solidColor) { idx = (i+1)%p.length; break; }
        config.solidColor = p[idx];
    }
    public static void cycleKeystrokesScale() { config.keystrokesScale = config.keystrokesScale.next(); }

    public static class WidgetBounds {
        public final int x, y, width, height;
        public WidgetBounds(int x, int y, int w, int h) { this.x = x; this.y = y; this.width = w; this.height = h; }
        public boolean contains(double px, double py) { return px >= x && px <= x + width && py >= y && py <= y + height; }
    }
}
