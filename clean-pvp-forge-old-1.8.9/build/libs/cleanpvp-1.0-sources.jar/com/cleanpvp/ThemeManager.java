package com.cleanpvp;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.*;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.ReflectionHelper;

import java.util.List;

public class ThemeManager {
    public static void initialize() {
        MinecraftForge.EVENT_BUS.register(new ThemeManager());
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onDrawScreenPost(GuiScreenEvent.DrawScreenEvent.Post event) {
        GuiScreen screen = event.gui;
        if (screen == null) return;

        Minecraft mc = Minecraft.func_71410_x();

        // 1. Cover Panorama and Logo on Main Menu
        if (screen instanceof GuiMainMenu) {
            drawGradientRect(0, 0, screen.field_146294_l, screen.field_146295_m, CleanPvpTheme.TOP_GRADIENT, CleanPvpTheme.BOTTOM_GRADIENT);
            drawCustomTitle(screen);
        }

        // 2. Render Modern Buttons over vanilla ones (to avoid breaking field references)
        try {
            List<GuiButton> buttonList = ReflectionHelper.getPrivateValue(GuiScreen.class, screen, "buttonList", "field_146292_n");
            for (GuiButton button : buttonList) {
                if (button.field_146125_m) {
                    drawModernButton(mc, button, event.mouseX, event.mouseY);
                }
            }
        } catch (Exception e) {
            // Fallback if reflection fails
        }
    }

    private void drawCustomTitle(GuiScreen screen) {
        String title = "CLEAN PVP";
        float scale = 3.2f;
        int textWidth = screen.field_146297_k.field_71466_p.func_78256_a(title);

        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b(screen.field_146294_l / 2f, 18f, 0);
        GlStateManager.func_179152_a(scale, scale, 1.0f);
        screen.field_146297_k.field_71466_p.func_175063_a(title, -textWidth / 2, 0, 0xFFFFFFFF);
        GlStateManager.func_179121_F();
    }

    private void drawModernButton(Minecraft mc, GuiButton button, int mouseX, int mouseY) {
        boolean hovered = mouseX >= button.field_146128_h && mouseY >= button.field_146129_i && mouseX < button.field_146128_h + button.field_146120_f && mouseY < button.field_146129_i + button.field_146121_g;
        
        int top = hovered ? CleanPvpTheme.BUTTON_HOVER_TOP : CleanPvpTheme.BUTTON_TOP;
        int bottom = hovered ? CleanPvpTheme.BUTTON_HOVER_BOTTOM : CleanPvpTheme.BUTTON_BOTTOM;
        
        if (!button.field_146124_l) {
            top = 0xFF3A5A4A;
            bottom = 0xFF2A4C66;
        }

        // Draw the modern background over the vanilla one
        drawGradientRect(button.field_146128_h, button.field_146129_i, button.field_146128_h + button.field_146120_f, button.field_146129_i + button.field_146121_g, top, bottom);
        
        // Draw the outline
        HudManager.drawOutline(button.field_146128_h, button.field_146129_i, button.field_146120_f, button.field_146121_g, CleanPvpTheme.BUTTON_BORDER);
        
        // Re-draw the text on top of our new background
        int textColor = 0xE0E0E0;
        if (!button.field_146124_l) {
            textColor = 0xA0A0A0;
        } else if (hovered) {
            textColor = 0xFFFFA0;
        }

        String text = button.field_146126_j;
        mc.field_71466_p.func_175063_a(text, button.field_146128_h + button.field_146120_f / 2 - mc.field_71466_p.func_78256_a(text) / 2, button.field_146129_i + (button.field_146121_g - 8) / 2, textColor);
    }

    public static void drawGradientRect(int left, int top, int right, int bottom, int startColor, int endColor) {
        float f = (float)(startColor >> 24 & 255) / 255.0F;
        float f1 = (float)(startColor >> 16 & 255) / 255.0F;
        float f2 = (float)(startColor >> 8 & 255) / 255.0F;
        float f3 = (float)(startColor & 255) / 255.0F;
        float f4 = (float)(endColor >> 24 & 255) / 255.0F;
        float f5 = (float)(endColor >> 16 & 255) / 255.0F;
        float f6 = (float)(endColor >> 8 & 255) / 255.0F;
        float f7 = (float)(endColor & 255) / 255.0F;
        
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_179120_a(770, 771, 1, 0);
        GlStateManager.func_179103_j(7425);
        Tessellator tessellator = Tessellator.func_178181_a();
        WorldRenderer worldrenderer = tessellator.func_178180_c();
        worldrenderer.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        worldrenderer.func_181662_b((double)right, (double)top, 0.0).func_181666_a(f1, f2, f3, f).func_181675_d();
        worldrenderer.func_181662_b((double)left, (double)top, 0.0).func_181666_a(f1, f2, f3, f).func_181675_d();
        worldrenderer.func_181662_b((double)left, (double)bottom, 0.0).func_181666_a(f5, f6, f7, f4).func_181675_d();
        worldrenderer.func_181662_b((double)right, (double)bottom, 0.0).func_181666_a(f5, f6, f7, f4).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_179103_j(7424);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
    }
}
